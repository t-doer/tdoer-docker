<?php

echo "This is a demo PHP web application. If you see this page, the nginx web server and php-fpm are successfully installed and
working.";